# Mentor Scoring - Design Guidelines

## Design Approach
**Reference-Based Approach** drawing from modern SaaS platforms (Linear, Stripe, Notion) combined with educational technology credibility. The design emphasizes trust, technical sophistication, and accessibility.

---

## Typography

**Font Family:** 
- Primary: Inter (headers, UI elements)
- Secondary: System fonts for body text

**Hierarchy:**
- Hero Headlines: text-5xl md:text-6xl lg:text-7xl, font-bold
- Section Headers: text-3xl md:text-4xl, font-bold
- Subsection Headers: text-2xl md:text-3xl, font-semibold
- Body Text: text-base md:text-lg, font-normal
- Small Text/Captions: text-sm, font-medium

---

## Layout System

**Spacing Primitives:** Use Tailwind units of **2, 4, 6, 8, 12, 16, 20, 24**
- Component padding: p-6, p-8, p-12
- Section spacing: py-16, py-20, py-24
- Element gaps: gap-4, gap-6, gap-8
- Margins: m-2, m-4, m-8

**Container Strategy:**
- Full-width sections with inner max-w-7xl for content
- Dashboard areas: max-w-6xl
- Text content: max-w-4xl for readability

---

## Page Structure & Sections

### Homepage
1. **Hero Section** (80vh): Large hero image showing mentor teaching/AI analysis visualization, headline emphasizing transformation from manual to AI-powered evaluation, primary CTA "Get Started" + secondary "Watch Demo"
2. **Problem Statement** (2-column): Left - statistics cards showing time wasted, inconsistency rates; Right - bullet points of manual evaluation pain points
3. **Solution Overview** (3-column grid): Multimodal analysis cards with icons - Audio Analysis, Video Analysis, Text Analysis
4. **How It Works** (stepped layout): 4-step process with numbered badges, images showing upload → analysis → scoring → insights
5. **Key Features Grid** (2x3 grid): Clarity scoring, engagement metrics, pacing analysis, confidence detection, content accuracy, real-time feedback
6. **Social Proof** (single row): Statistics banner - "10K+ educators evaluated", "95% accuracy", "50hrs saved monthly"
7. **CTA Section**: Full-width gradient background, centered messaging

### Machine Learning Page
1. **Hero**: Technical illustration of ML pipeline
2. **Core Capabilities** (4-column): Prediction, Classification, Pattern Recognition, Continuous Improvement - each with icon, title, description
3. **Model Architecture** (centered diagram): Visual flowchart showing data input → processing → output
4. **Performance Metrics** (stat cards): Accuracy rates, processing speed, improvement over time graphs

### Innovation Highlights
1. **Hero**: Split-screen - traditional evaluation vs AI evaluation comparison
2. **Feature Showcase** (alternating layout): 
   - Multimodal Analysis (image left, text right)
   - Explainable Scoring (text left, image right)
   - Scalability (image left, text right)
   - Bias-Free Evaluation (text left, image right)

### Ethics Page
1. **Hero**: Centered messaging on responsible AI
2. **Pillars** (3-column): Data Privacy, Transparency, Accountability - detailed cards
3. **Compliance Section**: Badges/certifications layout
4. **FAQ Accordion**: Common ethical concerns

### Dashboard Mockup
1. **Header**: Navigation + user profile
2. **Sidebar**: Upload video, View reports, Settings, Help
3. **Main Area**: 
   - Upload zone (large dashed border area with drag-drop)
   - Recent analyses table
   - Score visualization cards (gauge charts for each metric)
   - Improvement insights timeline

### Contact Page
1. **Split Layout** (60/40):
   - Left: Contact form (Name, Email, Subject, Message fields)
   - Right: Contact info cards, office hours, social links, map placeholder

---

## Component Library

**Navigation:** Sticky header with logo left, nav links center, CTA button right

**Buttons:** 
- Primary: Rounded corners (rounded-lg), medium padding (px-6 py-3)
- Secondary: Outlined variant
- On images: Backdrop blur effect (backdrop-blur-md)

**Cards:** 
- White background, subtle shadow (shadow-lg)
- Rounded corners (rounded-xl)
- Padding p-6 to p-8
- Hover: slight scale transform (hover:scale-105 transition)

**Forms:** 
- Input fields: Border (border-2), rounded (rounded-lg), padding (px-4 py-3)
- Labels: Above fields, font-medium, text-sm

**Data Visualization:**
- Gauge charts for scoring metrics (0-100 scale)
- Timeline for improvement tracking
- Bar charts for comparison data
- Use gradient fills for visual interest

**Icons:** Use Heroicons throughout for consistency

---

## Images

**Hero Images:**
1. Homepage: Wide shot of mentor teaching with overlay of AI analysis indicators/metrics visualization
2. ML Page: Abstract visualization of neural networks or data flowing through ML pipeline
3. Innovation Page: Before/after comparison showing manual clipboard vs. sleek AI dashboard
4. Ethics Page: Diverse group of educators using technology responsibly

**Section Images:**
- Solution cards: Icon-based illustrations for audio/video/text analysis
- How It Works: Screenshots of actual interface at each step
- Dashboard: Full mockup screenshots showing scoring outputs
- Features: Combination of icons and micro-illustrations

**Image Treatment:** All images should have subtle gradients overlays where text appears, rounded corners (rounded-2xl), and professional photography style

---

## Animations

Use sparingly and purposefully:
- Fade-in on scroll for section reveals (opacity transitions)
- Gentle hover lifts on cards (transform: translateY)
- Number count-up animations for statistics
- Progress indicators during "upload" interactions on dashboard
- NO complex scroll-driven narratives or parallax effects

---

## Accessibility

- Minimum contrast ratio 4.5:1 for all text
- Focus states: Visible outline (ring-2 ring-offset-2)
- All interactive elements keyboard accessible
- Form labels always visible and associated
- Alt text for all meaningful images
- Semantic HTML structure (header, nav, main, section, footer)