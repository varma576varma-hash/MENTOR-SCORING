import Footer from "../layout/Footer";

export default function FooterExample() {
  return <Footer />;
}
