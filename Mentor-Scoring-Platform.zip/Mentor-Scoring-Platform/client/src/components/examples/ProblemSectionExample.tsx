import ProblemSection from "../sections/ProblemSection";

export default function ProblemSectionExample() {
  return <ProblemSection />;
}
