import SolutionSection from "../sections/SolutionSection";

export default function SolutionSectionExample() {
  return <SolutionSection />;
}
