import HeroSection from "../sections/HeroSection";

export default function HeroSectionExample() {
  return <HeroSection />;
}
