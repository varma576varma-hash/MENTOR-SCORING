import MLSection from "../sections/MLSection";

export default function MLSectionExample() {
  return <MLSection />;
}
