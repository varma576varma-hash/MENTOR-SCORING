import ContactSection from "../sections/ContactSection";

export default function ContactSectionExample() {
  return <ContactSection />;
}
