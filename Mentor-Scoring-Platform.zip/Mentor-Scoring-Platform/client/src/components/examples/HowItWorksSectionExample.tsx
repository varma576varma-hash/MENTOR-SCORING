import HowItWorksSection from "../sections/HowItWorksSection";

export default function HowItWorksSectionExample() {
  return <HowItWorksSection />;
}
