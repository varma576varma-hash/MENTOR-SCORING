import DashboardSection from "../sections/DashboardSection";

export default function DashboardSectionExample() {
  return <DashboardSection />;
}
