import StatsSection from "../sections/StatsSection";

export default function StatsSectionExample() {
  return <StatsSection />;
}
