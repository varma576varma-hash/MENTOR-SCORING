import InnovationSection from "../sections/InnovationSection";

export default function InnovationSectionExample() {
  return <InnovationSection />;
}
