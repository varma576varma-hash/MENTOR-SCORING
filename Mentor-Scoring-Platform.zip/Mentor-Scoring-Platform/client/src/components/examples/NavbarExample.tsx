import Navbar from "../layout/Navbar";

export default function NavbarExample() {
  return <Navbar />;
}
