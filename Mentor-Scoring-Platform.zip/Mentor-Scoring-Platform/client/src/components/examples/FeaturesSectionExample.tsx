import FeaturesSection from "../sections/FeaturesSection";

export default function FeaturesSectionExample() {
  return <FeaturesSection />;
}
