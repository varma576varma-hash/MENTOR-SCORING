import EthicsSection from "../sections/EthicsSection";

export default function EthicsSectionExample() {
  return <EthicsSection />;
}
