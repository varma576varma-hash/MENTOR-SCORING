import CTASection from "../sections/CTASection";

export default function CTASectionExample() {
  return <CTASection />;
}
