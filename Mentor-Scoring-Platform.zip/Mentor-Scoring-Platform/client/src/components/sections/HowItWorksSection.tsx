import { Card, CardContent } from "@/components/ui/card";
import { Upload, Cpu, BarChart3, TrendingUp } from "lucide-react";

const steps = [
  {
    icon: Upload,
    step: "01",
    title: "Upload Video",
    description: "Simply upload a recorded teaching session. We support all major video formats up to 2 hours in length.",
  },
  {
    icon: Cpu,
    step: "02",
    title: "AI Processing",
    description: "Our multimodal AI analyzes audio, video, and transcribed text simultaneously for comprehensive evaluation.",
  },
  {
    icon: BarChart3,
    step: "03",
    title: "Receive Scores",
    description: "Get detailed scoring across all metrics with clear visualizations and breakdown by category.",
  },
  {
    icon: TrendingUp,
    step: "04",
    title: "Improve Performance",
    description: "Access personalized recommendations and track progress over time with historical analytics.",
  },
];

export default function HowItWorksSection() {
  return (
    <section className="py-20">
      <div className="mx-auto max-w-7xl px-4 md:px-6">
        <div className="text-center">
          <h2 className="text-3xl font-bold md:text-4xl" data-testid="text-how-it-works-title">
            How It Works
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
            From video upload to actionable insights in just four simple steps.
          </p>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {steps.map((item, index) => (
            <Card key={index} className="relative">
              <CardContent className="p-6">
                <div className="mb-4 text-4xl font-bold text-primary/20">
                  {item.step}
                </div>
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-primary">
                  <item.icon className="h-6 w-6 text-primary-foreground" />
                </div>
                <h3 className="mb-2 text-lg font-semibold" data-testid={`text-step-title-${index}`}>
                  {item.title}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {item.description}
                </p>
              </CardContent>
              {index < steps.length - 1 && (
                <div className="absolute -right-3 top-1/2 hidden h-0.5 w-6 bg-border lg:block" />
              )}
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
