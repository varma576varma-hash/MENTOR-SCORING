import { Card, CardContent } from "@/components/ui/card";
import { Clock, AlertTriangle, Users, TrendingDown } from "lucide-react";

const problems = [
  {
    icon: Clock,
    stat: "40+ hours",
    label: "spent per evaluation cycle",
    description: "Manual reviews consume weeks of administrative time that could be spent on actual teaching improvement.",
  },
  {
    icon: AlertTriangle,
    stat: "67%",
    label: "inconsistency rate",
    description: "Human evaluators often disagree, leading to unreliable and disputed assessment outcomes.",
  },
  {
    icon: Users,
    stat: "Limited",
    label: "scalability",
    description: "As programs grow, maintaining evaluation quality becomes impossible with manual methods.",
  },
  {
    icon: TrendingDown,
    stat: "3x",
    label: "higher bias risk",
    description: "Unconscious biases affect manual scoring, disadvantaging certain mentor demographics.",
  },
];

export default function ProblemSection() {
  return (
    <section className="bg-card py-20">
      <div className="mx-auto max-w-7xl px-4 md:px-6">
        <div className="text-center">
          <h2 className="text-3xl font-bold md:text-4xl" data-testid="text-problem-title">
            The Problem with Manual Evaluation
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
            Traditional mentor assessment methods are failing educational institutions
            and the mentors they serve.
          </p>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {problems.map((problem, index) => (
            <Card key={index} className="border-destructive/20 bg-destructive/5">
              <CardContent className="p-6">
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-destructive/10">
                  <problem.icon className="h-6 w-6 text-destructive" />
                </div>
                <div className="mb-1 text-2xl font-bold" data-testid={`text-problem-stat-${index}`}>
                  {problem.stat}
                </div>
                <div className="mb-3 text-sm font-medium text-muted-foreground">
                  {problem.label}
                </div>
                <p className="text-sm text-muted-foreground">
                  {problem.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
