import { Card, CardContent } from "@/components/ui/card";
import { Lock, Eye, Scale, Shield, FileCheck, Users } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import ethicsImage from "@assets/generated_images/diverse_educators_using_ai_technology.png";

const pillars = [
  {
    icon: Lock,
    title: "Data Privacy",
    description: "All video data is encrypted, processed securely, and can be deleted upon request. We never share individual data with third parties.",
    points: ["End-to-end encryption", "GDPR & FERPA compliant", "Right to deletion"],
  },
  {
    icon: Eye,
    title: "Transparency",
    description: "Our scoring algorithms are documented and explainable. Users can understand exactly how their scores were determined.",
    points: ["Open methodology", "Score explanations", "Regular audits"],
  },
  {
    icon: Scale,
    title: "Accountability",
    description: "We maintain human oversight, regular bias audits, and clear escalation paths for disputed evaluations.",
    points: ["Human review option", "Appeal process", "Continuous monitoring"],
  },
];

const faqs = [
  {
    question: "How do you ensure the AI doesn't have biases?",
    answer: "We conduct regular bias audits across demographic groups and continuously retrain our models to minimize any detected disparities. Our training data is carefully curated to represent diverse teaching styles and backgrounds.",
  },
  {
    question: "Can mentors dispute their AI-generated scores?",
    answer: "Yes, every evaluation includes an appeal option. Disputed scores are reviewed by human experts who can override AI decisions when appropriate.",
  },
  {
    question: "Who has access to the evaluation data?",
    answer: "Only authorized administrators and the mentors themselves can access evaluation data. All access is logged and auditable.",
  },
  {
    question: "Is my video stored permanently?",
    answer: "Videos can be deleted after processing. We offer configurable retention policies, and you can request complete data deletion at any time.",
  },
];

export default function EthicsSection() {
  return (
    <section className="py-20">
      <div className="mx-auto max-w-7xl px-4 md:px-6">
        <div className="grid items-start gap-12 lg:grid-cols-2">
          <div>
            <h2 className="text-3xl font-bold md:text-4xl" data-testid="text-ethics-title">
              Responsible AI
              <span className="block text-primary">Built on Ethics</span>
            </h2>
            <p className="mt-4 text-muted-foreground">
              We believe AI in education must be developed and deployed responsibly.
              Our commitment to ethical AI is embedded in every aspect of our platform.
            </p>

            <Card className="mt-8 overflow-hidden">
              <img
                src={ethicsImage}
                alt="Diverse educators using technology"
                className="aspect-video w-full object-cover"
              />
            </Card>
          </div>

          <div className="space-y-6">
            {pillars.map((pillar, index) => (
              <Card key={index}>
                <CardContent className="p-6">
                  <div className="flex gap-4">
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                      <pillar.icon className="h-6 w-6 text-primary" />
                    </div>
                    <div>
                      <h3 className="mb-2 text-lg font-semibold" data-testid={`text-ethics-pillar-${index}`}>
                        {pillar.title}
                      </h3>
                      <p className="mb-4 text-sm text-muted-foreground">
                        {pillar.description}
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {pillar.points.map((point, pIndex) => (
                          <span
                            key={pIndex}
                            className="inline-flex items-center gap-1 rounded-full bg-muted px-3 py-1 text-xs font-medium"
                          >
                            <Shield className="h-3 w-3" />
                            {point}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            <Card>
              <CardContent className="p-6">
                <h3 className="mb-4 text-lg font-semibold">Frequently Asked Questions</h3>
                <Accordion type="single" collapsible className="w-full">
                  {faqs.map((faq, index) => (
                    <AccordionItem key={index} value={`item-${index}`}>
                      <AccordionTrigger className="text-left text-sm" data-testid={`button-faq-${index}`}>
                        {faq.question}
                      </AccordionTrigger>
                      <AccordionContent className="text-sm text-muted-foreground">
                        {faq.answer}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
