import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { 
  Upload, 
  Play, 
  BarChart3, 
  TrendingUp, 
  MessageSquare,
  Activity,
  Timer,
  Shield,
  CheckCircle2,
  FileVideo,
  Clock,
  ChevronRight
} from "lucide-react";

// todo: remove mock functionality
const mockScores = [
  { label: "Clarity", score: 87, icon: MessageSquare, trend: "+5%" },
  { label: "Engagement", score: 92, icon: Activity, trend: "+8%" },
  { label: "Pacing", score: 78, icon: Timer, trend: "+2%" },
  { label: "Confidence", score: 85, icon: Shield, trend: "+12%" },
  { label: "Accuracy", score: 94, icon: CheckCircle2, trend: "+3%" },
];

// todo: remove mock functionality
const mockRecentAnalyses = [
  { id: 1, title: "Introduction to Machine Learning", date: "Dec 10, 2024", score: 88, status: "complete" },
  { id: 2, title: "Data Structures Overview", date: "Dec 8, 2024", score: 91, status: "complete" },
  { id: 3, title: "Python Basics Workshop", date: "Dec 5, 2024", score: 76, status: "complete" },
];

// todo: remove mock functionality
const mockInsights = [
  { text: "Increase pause duration after key concepts", impact: "High", category: "Pacing" },
  { text: "Use more visual examples in explanations", impact: "Medium", category: "Clarity" },
  { text: "Maintain consistent energy throughout", impact: "Medium", category: "Engagement" },
];

export default function DashboardSection() {
  const [isDragging, setIsDragging] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    simulateUpload();
  };

  const simulateUpload = () => {
    setIsUploading(true);
    setUploadProgress(0);
    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsUploading(false);
          return 100;
        }
        return prev + 10;
      });
    }, 200);
  };

  return (
    <section className="bg-card py-20">
      <div className="mx-auto max-w-7xl px-4 md:px-6">
        <div className="text-center">
          <h2 className="text-3xl font-bold md:text-4xl" data-testid="text-dashboard-title">
            Dashboard Preview
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
            A glimpse into the powerful evaluation dashboard mentors and administrators use.
          </p>
        </div>

        <div className="mt-12 grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 space-y-6">
            <Card
              className={`border-2 border-dashed transition-colors ${
                isDragging ? "border-primary bg-primary/5" : "border-muted"
              }`}
              onDragOver={(e) => {
                e.preventDefault();
                setIsDragging(true);
              }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
            >
              <CardContent className="flex flex-col items-center justify-center p-12 text-center">
                <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                  <Upload className="h-8 w-8 text-primary" />
                </div>
                <h3 className="mb-2 text-lg font-semibold">Upload Teaching Video</h3>
                <p className="mb-4 text-sm text-muted-foreground">
                  Drag and drop your video here, or click to browse
                </p>
                {isUploading ? (
                  <div className="w-full max-w-xs space-y-2">
                    <Progress value={uploadProgress} />
                    <p className="text-sm text-muted-foreground">{uploadProgress}% uploaded</p>
                  </div>
                ) : (
                  <Button onClick={simulateUpload} data-testid="button-upload-video">
                    <FileVideo className="mr-2 h-4 w-4" />
                    Select Video
                  </Button>
                )}
              </CardContent>
            </Card>

            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {mockScores.slice(0, 3).map((metric, index) => (
                <Card key={index}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                          <metric.icon className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <p className="text-sm text-muted-foreground">{metric.label}</p>
                          <p className="text-2xl font-bold" data-testid={`text-score-${metric.label.toLowerCase()}`}>
                            {metric.score}
                          </p>
                        </div>
                      </div>
                      <Badge variant="secondary" className="text-green-600">
                        <TrendingUp className="mr-1 h-3 w-3" />
                        {metric.trend}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Scoring Breakdown
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {mockScores.map((metric, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="flex items-center gap-2">
                          <metric.icon className="h-4 w-4 text-muted-foreground" />
                          {metric.label}
                        </span>
                        <span className="font-medium">{metric.score}/100</span>
                      </div>
                      <Progress value={metric.score} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Clock className="h-5 w-5" />
                  Recent Analyses
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {mockRecentAnalyses.map((analysis) => (
                  <div
                    key={analysis.id}
                    className="flex items-center justify-between rounded-lg bg-muted/50 p-3"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-medium text-sm" data-testid={`text-analysis-${analysis.id}`}>
                        {analysis.title}
                      </p>
                      <p className="text-xs text-muted-foreground">{analysis.date}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary">{analysis.score}</Badge>
                      <Button size="icon" variant="ghost" data-testid={`button-view-analysis-${analysis.id}`}>
                        <Play className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Improvement Insights
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {mockInsights.map((insight, index) => (
                  <div key={index} className="rounded-lg border p-3">
                    <div className="mb-2 flex items-center justify-between gap-2">
                      <Badge variant="outline">{insight.category}</Badge>
                      <Badge
                        variant={insight.impact === "High" ? "default" : "secondary"}
                      >
                        {insight.impact} Impact
                      </Badge>
                    </div>
                    <p className="text-sm" data-testid={`text-insight-${index}`}>{insight.text}</p>
                  </div>
                ))}
                <Button variant="outline" className="w-full gap-2" data-testid="button-view-all-insights">
                  View All Insights
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
