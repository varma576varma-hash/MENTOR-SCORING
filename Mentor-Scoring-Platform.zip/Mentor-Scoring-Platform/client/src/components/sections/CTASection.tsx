import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles } from "lucide-react";

export default function CTASection() {
  return (
    <section className="py-20">
      <div className="mx-auto max-w-7xl px-4 md:px-6">
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-primary to-chart-2 p-8 md:p-12 lg:p-16">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg width=%2260%22 height=%2260%22 viewBox=%220 0 60 60%22 xmlns=%22http://www.w3.org/2000/svg%22%3E%3Cg fill=%22none%22 fill-rule=%22evenodd%22%3E%3Cg fill=%22%23ffffff%22 fill-opacity=%220.05%22%3E%3Ccircle cx=%2230%22 cy=%2230%22 r=%222%22/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')]" />
          
          <div className="relative mx-auto max-w-3xl text-center">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full bg-white/20 px-4 py-2 text-sm font-medium text-white">
              <Sparkles className="h-4 w-4" />
              Start Free Today
            </div>
            
            <h2 className="text-3xl font-bold text-white md:text-4xl lg:text-5xl" data-testid="text-cta-title">
              Ready to Transform Your Mentor Evaluation?
            </h2>
            
            <p className="mx-auto mt-6 max-w-xl text-lg text-white/80">
              Join thousands of educational institutions already using AI-powered 
              evaluation to improve teaching quality and mentor development.
            </p>
            
            <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">
              <Button
                size="lg"
                variant="secondary"
                className="gap-2 bg-white text-primary hover:bg-white/90"
                data-testid="button-cta-get-started"
              >
                Get Started Free
                <ArrowRight className="h-4 w-4" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="gap-2 border-white/30 bg-white/10 text-white hover:bg-white/20"
                data-testid="button-cta-schedule-demo"
              >
                Schedule a Demo
              </Button>
            </div>
            
            <p className="mt-6 text-sm text-white/60">
              No credit card required. Free trial includes 5 video analyses.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
