import { Card, CardContent } from "@/components/ui/card";
import { GitBranch, Target, Search, RefreshCw } from "lucide-react";
import mlImage from "@assets/generated_images/neural_network_data_visualization.png";

const capabilities = [
  {
    icon: Target,
    title: "Prediction",
    description: "Forecast mentor performance trajectories and identify potential areas of improvement before they become issues.",
  },
  {
    icon: GitBranch,
    title: "Classification",
    description: "Categorize teaching styles, strengths, and development needs with high accuracy using advanced neural networks.",
  },
  {
    icon: Search,
    title: "Pattern Recognition",
    description: "Identify successful teaching patterns across thousands of sessions to benchmark against best practices.",
  },
  {
    icon: RefreshCw,
    title: "Continuous Improvement",
    description: "Self-learning algorithms that improve accuracy over time by incorporating new data and feedback.",
  },
];

export default function MLSection() {
  return (
    <section className="py-20">
      <div className="mx-auto max-w-7xl px-4 md:px-6">
        <div className="grid items-center gap-12 lg:grid-cols-2">
          <div>
            <h2 className="text-3xl font-bold md:text-4xl" data-testid="text-ml-title">
              Powered by Advanced
              <span className="block text-primary">Machine Learning</span>
            </h2>
            <p className="mt-4 text-muted-foreground">
              Our proprietary AI models are trained on thousands of teaching sessions 
              to deliver accurate, consistent, and fair evaluations every time.
            </p>

            <div className="mt-8 grid gap-6 sm:grid-cols-2">
              {capabilities.map((capability, index) => (
                <div key={index} className="flex gap-4">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                    <capability.icon className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold" data-testid={`text-ml-capability-${index}`}>
                      {capability.title}
                    </h3>
                    <p className="mt-1 text-sm text-muted-foreground">
                      {capability.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative">
            <Card className="overflow-hidden">
              <img
                src={mlImage}
                alt="Machine learning visualization"
                className="aspect-video w-full object-cover"
              />
            </Card>
            <Card className="absolute -bottom-6 -left-6 hidden max-w-xs md:block">
              <CardContent className="p-4">
                <div className="flex items-center gap-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/20">
                    <span className="text-xl font-bold text-green-600">98%</span>
                  </div>
                  <div>
                    <p className="font-semibold">Model Accuracy</p>
                    <p className="text-sm text-muted-foreground">Latest benchmark results</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
