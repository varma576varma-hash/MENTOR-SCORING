import { Card, CardContent } from "@/components/ui/card";
import { Mic, Video, FileText, Sparkles } from "lucide-react";

const solutions = [
  {
    icon: Mic,
    title: "Audio Analysis",
    description: "Advanced speech recognition analyzes tone, pacing, clarity, and vocal patterns to assess verbal communication effectiveness.",
    features: ["Speech clarity detection", "Pace analysis", "Tone evaluation"],
  },
  {
    icon: Video,
    title: "Video Analysis",
    description: "Computer vision evaluates body language, eye contact, gestures, and overall presence during teaching sessions.",
    features: ["Gesture recognition", "Eye contact tracking", "Presence scoring"],
  },
  {
    icon: FileText,
    title: "Text Analysis",
    description: "NLP processes transcripts to evaluate content accuracy, explanation quality, and pedagogical structure.",
    features: ["Content accuracy", "Explanation quality", "Topic coverage"],
  },
];

export default function SolutionSection() {
  return (
    <section className="py-20">
      <div className="mx-auto max-w-7xl px-4 md:px-6">
        <div className="text-center">
          <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
            <Sparkles className="h-4 w-4" />
            AI-Powered Solution
          </div>
          <h2 className="text-3xl font-bold md:text-4xl" data-testid="text-solution-title">
            Multimodal AI Analysis
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
            Our system combines three powerful analysis modalities to deliver 
            comprehensive, objective mentor evaluations.
          </p>
        </div>

        <div className="mt-12 grid gap-8 md:grid-cols-3">
          {solutions.map((solution, index) => (
            <Card key={index} className="relative overflow-visible">
              <CardContent className="p-8">
                <div className="mb-6 flex h-14 w-14 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                  <solution.icon className="h-7 w-7" />
                </div>
                <h3 className="mb-3 text-xl font-semibold" data-testid={`text-solution-title-${index}`}>
                  {solution.title}
                </h3>
                <p className="mb-6 text-muted-foreground">
                  {solution.description}
                </p>
                <ul className="space-y-2">
                  {solution.features.map((feature, fIndex) => (
                    <li key={fIndex} className="flex items-center gap-2 text-sm">
                      <span className="h-1.5 w-1.5 rounded-full bg-primary" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
