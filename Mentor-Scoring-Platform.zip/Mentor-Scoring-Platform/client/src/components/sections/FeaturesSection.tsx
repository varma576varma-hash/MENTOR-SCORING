import { Card, CardContent } from "@/components/ui/card";
import { 
  MessageSquare, 
  Activity, 
  Timer, 
  Shield, 
  CheckCircle2, 
  Lightbulb 
} from "lucide-react";

const features = [
  {
    icon: MessageSquare,
    title: "Clarity of Explanation",
    description: "Measures how clearly concepts are communicated, including vocabulary choice, example usage, and logical flow of ideas.",
  },
  {
    icon: Activity,
    title: "Engagement Level",
    description: "Analyzes audience interaction, enthusiasm in delivery, and techniques used to maintain learner attention.",
  },
  {
    icon: Timer,
    title: "Pacing Analysis",
    description: "Evaluates speed of delivery, appropriate pauses, and time allocation across different topics.",
  },
  {
    icon: Shield,
    title: "Confidence Detection",
    description: "Assesses vocal confidence, body language assurance, and handling of questions or challenges.",
  },
  {
    icon: CheckCircle2,
    title: "Content Accuracy",
    description: "Verifies factual correctness, up-to-date information, and proper coverage of required material.",
  },
  {
    icon: Lightbulb,
    title: "Real-Time Feedback",
    description: "Provides instant insights and actionable recommendations for immediate improvement.",
  },
];

export default function FeaturesSection() {
  return (
    <section className="bg-card py-20">
      <div className="mx-auto max-w-7xl px-4 md:px-6">
        <div className="text-center">
          <h2 className="text-3xl font-bold md:text-4xl" data-testid="text-features-title">
            What We Measure
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
            Comprehensive metrics that capture every aspect of teaching excellence.
          </p>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {features.map((feature, index) => (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <feature.icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="mb-2 text-lg font-semibold" data-testid={`text-feature-title-${index}`}>
                  {feature.title}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {feature.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
