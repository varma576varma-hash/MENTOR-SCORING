import { Users, Target, Clock, Award } from "lucide-react";

const stats = [
  { icon: Users, value: "10,000+", label: "Mentors Evaluated" },
  { icon: Target, value: "95%", label: "Accuracy Rate" },
  { icon: Clock, value: "50hrs", label: "Saved Monthly" },
  { icon: Award, value: "500+", label: "Institutions" },
];

export default function StatsSection() {
  return (
    <section className="border-y bg-primary py-12">
      <div className="mx-auto max-w-7xl px-4 md:px-6">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {stats.map((stat, index) => (
            <div key={index} className="text-center">
              <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-white/10">
                <stat.icon className="h-6 w-6 text-primary-foreground" />
              </div>
              <div className="text-3xl font-bold text-primary-foreground" data-testid={`text-stat-value-${index}`}>
                {stat.value}
              </div>
              <div className="text-sm text-primary-foreground/70">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
