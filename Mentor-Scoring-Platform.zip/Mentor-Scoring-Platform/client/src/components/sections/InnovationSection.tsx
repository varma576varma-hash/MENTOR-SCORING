import { Card, CardContent } from "@/components/ui/card";
import { Layers, Eye, Scale, ShieldCheck } from "lucide-react";
import innovationImage from "@assets/generated_images/traditional_vs_ai_evaluation_comparison.png";

const innovations = [
  {
    icon: Layers,
    title: "Multimodal Analysis",
    description: "Unlike single-channel tools, we analyze audio, video, and text simultaneously for a complete picture of teaching effectiveness.",
    highlight: "3-channel AI",
  },
  {
    icon: Eye,
    title: "Explainable Scoring",
    description: "Every score comes with detailed explanations. No black boxes - understand exactly why each metric was assigned.",
    highlight: "Full transparency",
  },
  {
    icon: Scale,
    title: "Infinite Scalability",
    description: "Evaluate one mentor or ten thousand with the same speed and consistency. Our cloud infrastructure scales automatically.",
    highlight: "Unlimited capacity",
  },
  {
    icon: ShieldCheck,
    title: "Bias-Free Evaluation",
    description: "Trained to ignore demographic factors and focus purely on teaching quality, ensuring fair assessments for all.",
    highlight: "Equity-first design",
  },
];

export default function InnovationSection() {
  return (
    <section className="bg-card py-20">
      <div className="mx-auto max-w-7xl px-4 md:px-6">
        <div className="text-center">
          <h2 className="text-3xl font-bold md:text-4xl" data-testid="text-innovation-title">
            Innovation Highlights
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
            What sets Mentor Scoring apart from traditional evaluation methods.
          </p>
        </div>

        <div className="mt-12">
          <Card className="overflow-hidden">
            <img
              src={innovationImage}
              alt="Traditional vs AI evaluation comparison"
              className="aspect-video w-full object-cover"
            />
          </Card>
        </div>

        <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          {innovations.map((innovation, index) => (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <innovation.icon className="h-6 w-6 text-primary" />
                </div>
                <div className="mb-2 inline-block rounded-full bg-primary/10 px-3 py-1 text-xs font-medium text-primary">
                  {innovation.highlight}
                </div>
                <h3 className="mb-2 text-lg font-semibold" data-testid={`text-innovation-title-${index}`}>
                  {innovation.title}
                </h3>
                <p className="text-sm text-muted-foreground">
                  {innovation.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
