import { Button } from "@/components/ui/button";
import { Play, ArrowRight } from "lucide-react";
import heroImage from "@assets/generated_images/mentor_with_ai_analysis_overlay.png";

export default function HeroSection() {
  return (
    <section className="relative min-h-[80vh] overflow-hidden">
      <div className="absolute inset-0">
        <img
          src={heroImage}
          alt="AI-powered mentor analysis"
          className="h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-black/40" />
      </div>
      
      <div className="relative mx-auto flex min-h-[80vh] max-w-7xl flex-col items-start justify-center px-4 py-20 md:px-6">
        <div className="max-w-2xl">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-2 text-sm text-white backdrop-blur-sm">
            <span className="h-2 w-2 rounded-full bg-green-400" />
            AI-Powered Evaluation System
          </div>
          
          <h1 className="text-4xl font-bold leading-tight text-white md:text-5xl lg:text-6xl">
            Transform How You
            <span className="block text-primary">Evaluate Mentors</span>
          </h1>
          
          <p className="mt-6 text-lg text-white/80 md:text-xl">
            Move beyond slow, subjective, and unscalable manual evaluations. 
            Our AI analyzes teaching videos through audio, video, and text to 
            deliver objective, consistent scoring in minutes.
          </p>
          
          <div className="mt-8 flex flex-wrap gap-4">
            <Button size="lg" className="gap-2" data-testid="button-hero-get-started">
              Get Started Free
              <ArrowRight className="h-4 w-4" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="gap-2 border-white/30 bg-white/10 text-white backdrop-blur-sm hover:bg-white/20"
              data-testid="button-hero-watch-demo"
            >
              <Play className="h-4 w-4" />
              Watch Demo
            </Button>
          </div>
          
          <div className="mt-12 flex flex-wrap items-center gap-8 text-white/60">
            <div className="flex items-center gap-2">
              <span className="text-2xl font-bold text-white">10K+</span>
              <span className="text-sm">Mentors Evaluated</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-2xl font-bold text-white">95%</span>
              <span className="text-sm">Accuracy Rate</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-2xl font-bold text-white">50hrs</span>
              <span className="text-sm">Saved Monthly</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
