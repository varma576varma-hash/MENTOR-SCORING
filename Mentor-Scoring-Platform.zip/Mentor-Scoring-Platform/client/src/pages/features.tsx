import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import FeaturesSection from "@/components/sections/FeaturesSection";
import HowItWorksSection from "@/components/sections/HowItWorksSection";
import CTASection from "@/components/sections/CTASection";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Mic, 
  Video, 
  FileText, 
  Brain, 
  Gauge, 
  LineChart, 
  Zap, 
  Globe 
} from "lucide-react";

const detailedFeatures = [
  {
    icon: Mic,
    title: "Speech Analysis",
    description: "Advanced algorithms analyze vocal patterns, tone variations, speaking pace, and articulation clarity to provide comprehensive audio feedback.",
    metrics: ["Words per minute", "Tone consistency", "Filler word detection"],
  },
  {
    icon: Video,
    title: "Visual Presence",
    description: "Computer vision evaluates body language, gestures, eye contact patterns, and overall visual engagement during teaching sessions.",
    metrics: ["Gesture frequency", "Eye contact score", "Movement analysis"],
  },
  {
    icon: FileText,
    title: "Content Analysis",
    description: "Natural language processing evaluates the structure, accuracy, and pedagogical quality of the content being delivered.",
    metrics: ["Topic coverage", "Explanation depth", "Logical flow"],
  },
  {
    icon: Brain,
    title: "Cognitive Load",
    description: "Measures how effectively concepts are broken down and whether the complexity matches the target audience level.",
    metrics: ["Complexity score", "Scaffolding analysis", "Comprehension prediction"],
  },
  {
    icon: Gauge,
    title: "Real-Time Scoring",
    description: "Get instant feedback as the AI processes your video, with scores updating in real-time across all metrics.",
    metrics: ["Live score updates", "Segment analysis", "Timeline markers"],
  },
  {
    icon: LineChart,
    title: "Progress Tracking",
    description: "Track improvement over time with historical analytics, trend analysis, and personalized growth recommendations.",
    metrics: ["Historical trends", "Improvement rate", "Goal tracking"],
  },
  {
    icon: Zap,
    title: "Instant Reports",
    description: "Receive detailed PDF reports immediately after analysis, ready to share with stakeholders or for personal review.",
    metrics: ["PDF export", "Summary highlights", "Action items"],
  },
  {
    icon: Globe,
    title: "Multi-Language",
    description: "Support for 50+ languages with localized scoring models trained on native speaker patterns for each language.",
    metrics: ["50+ languages", "Accent adaptation", "Cultural context"],
  },
];

export default function Features() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <section className="py-20">
          <div className="mx-auto max-w-7xl px-4 md:px-6">
            <div className="text-center">
              <h1 className="text-4xl font-bold md:text-5xl" data-testid="text-features-page-title">
                Powerful Features for
                <span className="block text-primary">Better Evaluation</span>
              </h1>
              <p className="mx-auto mt-4 max-w-2xl text-lg text-muted-foreground">
                Discover the comprehensive suite of tools designed to transform 
                how you evaluate and improve mentor performance.
              </p>
            </div>

            <div className="mt-16 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              {detailedFeatures.map((feature, index) => (
                <Card key={index}>
                  <CardContent className="p-6">
                    <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                      <feature.icon className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="mb-2 text-lg font-semibold" data-testid={`text-detailed-feature-${index}`}>
                      {feature.title}
                    </h3>
                    <p className="mb-4 text-sm text-muted-foreground">
                      {feature.description}
                    </p>
                    <ul className="space-y-1">
                      {feature.metrics.map((metric, mIndex) => (
                        <li key={mIndex} className="flex items-center gap-2 text-xs text-muted-foreground">
                          <span className="h-1 w-1 rounded-full bg-primary" />
                          {metric}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <FeaturesSection />
        <HowItWorksSection />
        <CTASection />
      </main>
      <Footer />
    </div>
  );
}
