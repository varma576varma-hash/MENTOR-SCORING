import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import MLSection from "@/components/sections/MLSection";
import CTASection from "@/components/sections/CTASection";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { 
  Brain, 
  Cpu, 
  Database, 
  Layers, 
  Network, 
  Workflow,
  ChartBar,
  Sparkles
} from "lucide-react";

const mlCapabilities = [
  {
    icon: Brain,
    title: "Deep Neural Networks",
    description: "Multi-layer neural architectures process complex teaching patterns with state-of-the-art accuracy.",
  },
  {
    icon: Layers,
    title: "Transfer Learning",
    description: "Models pre-trained on millions of teaching sessions, fine-tuned for your specific context.",
  },
  {
    icon: Network,
    title: "Attention Mechanisms",
    description: "Transformer-based attention focuses on the most important moments in each session.",
  },
  {
    icon: Workflow,
    title: "Ensemble Methods",
    description: "Multiple specialized models combine predictions for robust, reliable scoring.",
  },
  {
    icon: Database,
    title: "Continuous Learning",
    description: "Models improve with every evaluation, incorporating feedback and new patterns.",
  },
  {
    icon: Cpu,
    title: "Edge Processing",
    description: "On-device preprocessing ensures fast uploads and preliminary analysis.",
  },
];

// todo: remove mock functionality
const performanceMetrics = [
  { label: "Clarity Detection", value: 97, benchmark: 85 },
  { label: "Engagement Analysis", value: 94, benchmark: 82 },
  { label: "Pacing Accuracy", value: 96, benchmark: 78 },
  { label: "Confidence Scoring", value: 93, benchmark: 80 },
  { label: "Content Verification", value: 98, benchmark: 88 },
];

export default function MachineLearning() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <section className="py-20">
          <div className="mx-auto max-w-7xl px-4 md:px-6">
            <div className="text-center">
              <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
                <Sparkles className="h-4 w-4" />
                Advanced Technology
              </div>
              <h1 className="text-4xl font-bold md:text-5xl" data-testid="text-ml-page-title">
                Machine Learning
                <span className="block text-primary">Under the Hood</span>
              </h1>
              <p className="mx-auto mt-4 max-w-2xl text-lg text-muted-foreground">
                Explore the sophisticated AI systems that power accurate, 
                fair, and insightful mentor evaluations.
              </p>
            </div>
          </div>
        </section>

        <MLSection />

        <section className="bg-card py-20">
          <div className="mx-auto max-w-7xl px-4 md:px-6">
            <div className="text-center">
              <h2 className="text-3xl font-bold md:text-4xl">ML Architecture</h2>
              <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
                Built on proven technologies used by the world's leading AI companies.
              </p>
            </div>

            <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {mlCapabilities.map((capability, index) => (
                <Card key={index}>
                  <CardContent className="p-6">
                    <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                      <capability.icon className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="mb-2 text-lg font-semibold" data-testid={`text-ml-arch-${index}`}>
                      {capability.title}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {capability.description}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="mx-auto max-w-7xl px-4 md:px-6">
            <div className="grid items-center gap-12 lg:grid-cols-2">
              <div>
                <h2 className="text-3xl font-bold md:text-4xl">
                  Performance That Speaks for Itself
                </h2>
                <p className="mt-4 text-muted-foreground">
                  Our models consistently outperform industry benchmarks across 
                  all evaluation metrics, validated through rigorous testing.
                </p>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <ChartBar className="h-5 w-5" />
                    Model Performance vs. Industry Benchmark
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {performanceMetrics.map((metric, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span>{metric.label}</span>
                        <span className="font-medium">{metric.value}%</span>
                      </div>
                      <div className="relative">
                        <Progress value={metric.value} className="h-3" />
                        <div
                          className="absolute top-0 h-3 w-0.5 bg-destructive"
                          style={{ left: `${metric.benchmark}%` }}
                        />
                      </div>
                      <p className="text-xs text-muted-foreground">
                        Industry benchmark: {metric.benchmark}%
                      </p>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        <CTASection />
      </main>
      <Footer />
    </div>
  );
}
