import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import ContactSection from "@/components/sections/ContactSection";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  MessageCircle, 
  Clock, 
  Headphones, 
  BookOpen 
} from "lucide-react";

const supportOptions = [
  {
    icon: MessageCircle,
    title: "Live Chat",
    description: "Get instant answers from our support team during business hours.",
    availability: "Mon-Fri, 9am-6pm EST",
  },
  {
    icon: Headphones,
    title: "Phone Support",
    description: "Speak directly with a product specialist for complex inquiries.",
    availability: "Enterprise customers",
  },
  {
    icon: BookOpen,
    title: "Knowledge Base",
    description: "Search our comprehensive documentation and tutorials.",
    availability: "24/7 self-service",
  },
  {
    icon: Clock,
    title: "Response Time",
    description: "We aim to respond to all inquiries within 24 hours.",
    availability: "Guaranteed SLA",
  },
];

export default function Contact() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <section className="py-20">
          <div className="mx-auto max-w-7xl px-4 md:px-6">
            <div className="text-center">
              <Badge variant="secondary" className="mb-4">
                We're Here to Help
              </Badge>
              <h1 className="text-4xl font-bold md:text-5xl" data-testid="text-contact-page-title">
                Contact Us
              </h1>
              <p className="mx-auto mt-4 max-w-2xl text-lg text-muted-foreground">
                Have questions about Mentor Scoring? Our team is ready to 
                help you transform your evaluation process.
              </p>
            </div>
          </div>
        </section>

        <section className="bg-card py-12">
          <div className="mx-auto max-w-7xl px-4 md:px-6">
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              {supportOptions.map((option, index) => (
                <Card key={index}>
                  <CardContent className="p-6 text-center">
                    <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                      <option.icon className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="mb-2 font-semibold" data-testid={`text-support-${index}`}>
                      {option.title}
                    </h3>
                    <p className="mb-3 text-sm text-muted-foreground">
                      {option.description}
                    </p>
                    <Badge variant="outline">{option.availability}</Badge>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <ContactSection />
      </main>
      <Footer />
    </div>
  );
}
