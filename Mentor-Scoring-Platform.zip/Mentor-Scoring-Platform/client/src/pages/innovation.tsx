import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import InnovationSection from "@/components/sections/InnovationSection";
import CTASection from "@/components/sections/CTASection";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Layers, 
  Eye, 
  Scale, 
  ShieldCheck, 
  Rocket, 
  Zap, 
  Globe, 
  Lock,
  CheckCircle2
} from "lucide-react";

const innovations = [
  {
    icon: Layers,
    title: "Multimodal Analysis",
    badge: "Core Innovation",
    description: "Unlike single-channel tools, our system analyzes audio, video, and text simultaneously, creating a holistic understanding of teaching effectiveness that no single modality can provide.",
    benefits: [
      "Captures verbal and non-verbal communication",
      "Correlates content with delivery style",
      "Identifies disconnect between what's said and shown",
    ],
  },
  {
    icon: Eye,
    title: "Explainable AI",
    badge: "Transparency",
    description: "Every score comes with detailed reasoning. Our XAI approach ensures educators understand exactly why they received each score, enabling targeted improvement.",
    benefits: [
      "No black-box decisions",
      "Clear improvement pathways",
      "Builds trust in AI systems",
    ],
  },
  {
    icon: Scale,
    title: "Infinite Scalability",
    badge: "Enterprise Ready",
    description: "Evaluate one mentor or ten thousand with identical speed and consistency. Our cloud-native architecture scales automatically to meet demand.",
    benefits: [
      "Process thousands simultaneously",
      "Consistent quality at any scale",
      "No infrastructure management",
    ],
  },
  {
    icon: ShieldCheck,
    title: "Bias Mitigation",
    badge: "Equity First",
    description: "Our models are trained and continuously audited to ignore demographic factors, focusing purely on teaching quality for truly fair assessments.",
    benefits: [
      "Regular bias audits",
      "Diverse training data",
      "Fairness metrics tracked",
    ],
  },
];

const futureFeatures = [
  { icon: Rocket, title: "Real-time Feedback", status: "Coming Q1" },
  { icon: Zap, title: "Live Session Analysis", status: "Coming Q2" },
  { icon: Globe, title: "100+ Languages", status: "Coming Q2" },
  { icon: Lock, title: "On-Premise Deployment", status: "Coming Q3" },
];

export default function Innovation() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <section className="py-20">
          <div className="mx-auto max-w-7xl px-4 md:px-6">
            <div className="text-center">
              <h1 className="text-4xl font-bold md:text-5xl" data-testid="text-innovation-page-title">
                Innovation at the Core
                <span className="block text-primary">Of Everything We Build</span>
              </h1>
              <p className="mx-auto mt-4 max-w-2xl text-lg text-muted-foreground">
                Discover the breakthrough technologies that make Mentor Scoring 
                the most advanced evaluation platform available.
              </p>
            </div>
          </div>
        </section>

        <section className="bg-card py-20">
          <div className="mx-auto max-w-7xl px-4 md:px-6">
            <div className="space-y-8">
              {innovations.map((innovation, index) => (
                <Card key={index}>
                  <CardContent className="p-8">
                    <div className="grid gap-8 lg:grid-cols-3">
                      <div className="lg:col-span-2">
                        <div className="mb-4 flex items-center gap-4">
                          <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                            <innovation.icon className="h-7 w-7" />
                          </div>
                          <div>
                            <Badge variant="secondary" className="mb-1">
                              {innovation.badge}
                            </Badge>
                            <h3 className="text-2xl font-bold" data-testid={`text-innovation-detail-${index}`}>
                              {innovation.title}
                            </h3>
                          </div>
                        </div>
                        <p className="text-muted-foreground">
                          {innovation.description}
                        </p>
                      </div>
                      <div className="space-y-3">
                        <p className="text-sm font-medium">Key Benefits:</p>
                        {innovation.benefits.map((benefit, bIndex) => (
                          <div key={bIndex} className="flex items-start gap-2">
                            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                            <span className="text-sm text-muted-foreground">{benefit}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <InnovationSection />

        <section className="py-20">
          <div className="mx-auto max-w-7xl px-4 md:px-6">
            <div className="text-center">
              <h2 className="text-3xl font-bold md:text-4xl">Coming Soon</h2>
              <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
                We're constantly innovating. Here's what's on our roadmap.
              </p>
            </div>

            <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              {futureFeatures.map((feature, index) => (
                <Card key={index} className="text-center">
                  <CardContent className="p-6">
                    <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-muted">
                      <feature.icon className="h-7 w-7 text-muted-foreground" />
                    </div>
                    <h3 className="mb-2 font-semibold">{feature.title}</h3>
                    <Badge variant="outline">{feature.status}</Badge>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <CTASection />
      </main>
      <Footer />
    </div>
  );
}
