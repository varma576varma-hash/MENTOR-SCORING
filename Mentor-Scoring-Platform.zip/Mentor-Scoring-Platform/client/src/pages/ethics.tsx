import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import EthicsSection from "@/components/sections/EthicsSection";
import CTASection from "@/components/sections/CTASection";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Shield, 
  Lock, 
  Eye, 
  Scale, 
  FileCheck, 
  Users,
  CheckCircle2,
  Award
} from "lucide-react";

const principles = [
  {
    icon: Lock,
    title: "Data Privacy & Security",
    description: "We implement industry-leading security measures to protect all user data. Video content is encrypted in transit and at rest, with strict access controls.",
    points: [
      "AES-256 encryption for all stored data",
      "SOC 2 Type II certified infrastructure",
      "Regular penetration testing and security audits",
      "Data residency options for compliance",
    ],
  },
  {
    icon: Eye,
    title: "Transparency & Explainability",
    description: "Our AI systems are designed to be understandable. Every evaluation includes detailed explanations of how scores were determined.",
    points: [
      "Score breakdowns by category and timestamp",
      "Natural language explanations for each metric",
      "Open methodology documentation",
      "Regular algorithm transparency reports",
    ],
  },
  {
    icon: Scale,
    title: "Fairness & Bias Mitigation",
    description: "We actively work to identify and eliminate bias in our AI models, ensuring fair treatment for all mentors regardless of background.",
    points: [
      "Quarterly bias audits across demographics",
      "Diverse training data sourcing",
      "Continuous model monitoring for drift",
      "Independent fairness reviews",
    ],
  },
  {
    icon: Users,
    title: "Human Oversight & Accountability",
    description: "AI should augment, not replace, human judgment. We maintain clear accountability structures and human review options.",
    points: [
      "Human appeal process for all evaluations",
      "Clear escalation paths for disputes",
      "Named accountability for AI decisions",
      "Regular ethics board reviews",
    ],
  },
];

const certifications = [
  { name: "SOC 2 Type II", status: "Certified" },
  { name: "GDPR Compliant", status: "Verified" },
  { name: "FERPA Compliant", status: "Verified" },
  { name: "ISO 27001", status: "In Progress" },
  { name: "CCPA Compliant", status: "Verified" },
  { name: "HIPAA Ready", status: "Available" },
];

export default function Ethics() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <section className="py-20">
          <div className="mx-auto max-w-7xl px-4 md:px-6">
            <div className="text-center">
              <div className="mb-4 inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
                <Shield className="h-4 w-4" />
                Responsible AI
              </div>
              <h1 className="text-4xl font-bold md:text-5xl" data-testid="text-ethics-page-title">
                Ethics & Trust
                <span className="block text-primary">At Our Foundation</span>
              </h1>
              <p className="mx-auto mt-4 max-w-2xl text-lg text-muted-foreground">
                We believe AI in education must be developed and deployed 
                responsibly. Learn about our commitment to ethical AI.
              </p>
            </div>
          </div>
        </section>

        <section className="bg-card py-20">
          <div className="mx-auto max-w-7xl px-4 md:px-6">
            <div className="space-y-8">
              {principles.map((principle, index) => (
                <Card key={index}>
                  <CardContent className="p-8">
                    <div className="grid gap-8 lg:grid-cols-3">
                      <div className="lg:col-span-2">
                        <div className="mb-4 flex items-center gap-4">
                          <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-primary text-primary-foreground">
                            <principle.icon className="h-7 w-7" />
                          </div>
                          <h3 className="text-2xl font-bold" data-testid={`text-ethics-principle-${index}`}>
                            {principle.title}
                          </h3>
                        </div>
                        <p className="text-muted-foreground">
                          {principle.description}
                        </p>
                      </div>
                      <div className="space-y-3">
                        {principle.points.map((point, pIndex) => (
                          <div key={pIndex} className="flex items-start gap-2">
                            <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                            <span className="text-sm text-muted-foreground">{point}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <EthicsSection />

        <section className="py-20">
          <div className="mx-auto max-w-7xl px-4 md:px-6">
            <div className="text-center">
              <h2 className="text-3xl font-bold md:text-4xl">
                Certifications & Compliance
              </h2>
              <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
                We maintain rigorous compliance with industry standards and regulations.
              </p>
            </div>

            <div className="mt-12 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {certifications.map((cert, index) => (
                <Card key={index}>
                  <CardContent className="flex items-center justify-between p-4">
                    <div className="flex items-center gap-3">
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                        <Award className="h-5 w-5 text-primary" />
                      </div>
                      <span className="font-medium" data-testid={`text-cert-${index}`}>{cert.name}</span>
                    </div>
                    <Badge
                      variant={cert.status === "Certified" || cert.status === "Verified" ? "default" : "secondary"}
                    >
                      {cert.status}
                    </Badge>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <CTASection />
      </main>
      <Footer />
    </div>
  );
}
