import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import DashboardSection from "@/components/sections/DashboardSection";
import CTASection from "@/components/sections/CTASection";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  LayoutDashboard, 
  Upload, 
  BarChart3, 
  TrendingUp, 
  Users,
  Settings,
  Bell,
  FileText
} from "lucide-react";

const dashboardFeatures = [
  {
    icon: Upload,
    title: "Easy Video Upload",
    description: "Drag and drop videos up to 2 hours long. Support for all major formats including MP4, WebM, and MOV.",
  },
  {
    icon: BarChart3,
    title: "Detailed Analytics",
    description: "Visual breakdowns of every metric with timeline scrubbing to see scores at specific moments.",
  },
  {
    icon: TrendingUp,
    title: "Progress Tracking",
    description: "Historical charts showing improvement over time with trend analysis and predictions.",
  },
  {
    icon: Users,
    title: "Team Management",
    description: "Manage multiple mentors, set benchmarks, and compare performance across teams.",
  },
  {
    icon: Settings,
    title: "Custom Scoring",
    description: "Configure custom scoring weights and add institution-specific evaluation criteria.",
  },
  {
    icon: Bell,
    title: "Smart Notifications",
    description: "Get alerts when analyses complete, scores drop, or mentors hit improvement milestones.",
  },
  {
    icon: FileText,
    title: "Export Reports",
    description: "Generate professional PDF reports with charts and recommendations for stakeholders.",
  },
  {
    icon: LayoutDashboard,
    title: "Custom Dashboards",
    description: "Build personalized dashboards with the widgets and metrics that matter most to you.",
  },
];

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main>
        <section className="py-20">
          <div className="mx-auto max-w-7xl px-4 md:px-6">
            <div className="text-center">
              <Badge variant="secondary" className="mb-4">
                Interactive Demo
              </Badge>
              <h1 className="text-4xl font-bold md:text-5xl" data-testid="text-dashboard-page-title">
                Your Evaluation
                <span className="block text-primary">Command Center</span>
              </h1>
              <p className="mx-auto mt-4 max-w-2xl text-lg text-muted-foreground">
                Experience the intuitive dashboard that puts powerful AI 
                evaluation at your fingertips.
              </p>
            </div>
          </div>
        </section>

        <DashboardSection />

        <section className="py-20">
          <div className="mx-auto max-w-7xl px-4 md:px-6">
            <div className="text-center">
              <h2 className="text-3xl font-bold md:text-4xl">Dashboard Features</h2>
              <p className="mx-auto mt-4 max-w-2xl text-muted-foreground">
                Everything you need to manage evaluations effectively.
              </p>
            </div>

            <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              {dashboardFeatures.map((feature, index) => (
                <Card key={index}>
                  <CardContent className="p-6">
                    <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                      <feature.icon className="h-6 w-6 text-primary" />
                    </div>
                    <h3 className="mb-2 font-semibold" data-testid={`text-dashboard-feature-${index}`}>
                      {feature.title}
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      {feature.description}
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        <CTASection />
      </main>
      <Footer />
    </div>
  );
}
